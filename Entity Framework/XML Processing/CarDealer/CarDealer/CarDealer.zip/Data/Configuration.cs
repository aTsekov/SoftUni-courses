﻿namespace CarDealer.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=.;Database=CarDealerXML;User Id=sa;Password=SoftUn!2021;MultipleActiveResultSets=true;TrustServerCertificate=True";
    }
}
