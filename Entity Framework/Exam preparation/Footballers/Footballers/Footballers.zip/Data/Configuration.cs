﻿namespace Footballers.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=FootballersExam;User Id=sa;Password=SoftUn!2021;MultipleActiveResultSets=true;TrustServerCertificate=True";

           
    }
}
