﻿namespace CommandPattern.Common
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class ErrorMessages
    {
        public const string InvalidCommandType = "Provided type {0} does not exist ot impelment ICommand interface";
    }
}
